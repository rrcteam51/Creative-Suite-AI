
import React from 'react';

export type IconType = 'image' | 'edit' | 'bolt' | 'aspectRatio';

interface IconProps extends React.SVGProps<SVGSVGElement> {
  icon: IconType;
}

const icons: Record<IconType, React.ReactNode> = {
  image: (
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
  ),
  edit: (
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.53 16.122a3 3 0 00-5.78 1.128 2.25 2.25 0 01-2.4 2.245 4.5 4.5 0 008.4-2.245c0-.399-.078-.78-.22-1.128zm0 0a15.998 15.998 0 003.388-1.62m-5.043-.025a15.998 15.998 0 011.622-3.385m5.043.025a15.998 15.998 0 001.622-3.385m3.388 1.62a15.998 15.998 0 00-1.62-3.385m0 0a15.998 15.998 0 01-3.388-1.621m-5.043.025a15.998 15.998 0 01-1.622 3.385m5.043-.025a15.998 15.998 0 00-1.622 3.385m-3.388-1.62a15.998 15.998 0 001.62 3.385m0 0a15.998 15.998 0 013.388 1.622m-5.043-.025a15.998 15.998 0 01-1.622-3.385" />
  ),
  bolt: (
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 13.5l10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75z" />
  ),
  aspectRatio: (
    <path strokeLinecap="round" strokeLinejoin="round" d="M6 20.25h12m-7.5-3.75v3.75m-3.75-3.75v3.75m0-12.75h1.5m-1.5 0v-1.5m1.5 0h-1.5m-3.75 0h1.5m-1.5 0v-1.5m1.5 0h-1.5M9 6.75h1.5m-1.5 0v-1.5m1.5 0h-1.5m-3 0h1.5m-1.5 0v-1.5m1.5 0h-1.5m1.5 9h-1.5m0 0v-1.5m1.5 1.5h-1.5m-1.5-1.5h1.5m-1.5 0v-1.5m1.5 1.5h-1.5m1.5-1.5h-1.5m0 0v-1.5m1.5 1.5h-1.5M15 6.75h1.5m-1.5 0v-1.5m1.5 0h-1.5m-1.5-1.5h1.5m-1.5 0v-1.5m1.5 1.5h-1.5m1.5 9h-1.5m0 0v-1.5m1.5 1.5h-1.5" />
  ),
};

export const Icon: React.FC<IconProps> = ({ icon, ...props }) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      fill="none"
      viewBox="0 0 24 24"
      strokeWidth={1.5}
      stroke="currentColor"
      {...props}
    >
      {icons[icon]}
    </svg>
  );
};
