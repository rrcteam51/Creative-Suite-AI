
import React, { useState, useCallback } from 'react';
import { generateImage } from '../services/geminiService';
import { AspectRatio } from '../types';
import Spinner from './Spinner';
import { Icon } from './Icon';

const aspectRatios: AspectRatio[] = ["1:1", "16:9", "9:16", "4:3", "3:4"];

const GenerateImage: React.FC = () => {
  const [prompt, setPrompt] = useState<string>('');
  const [selectedAspectRatio, setSelectedAspectRatio] = useState<AspectRatio>('1:1');
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) {
      setError("Please enter a prompt.");
      return;
    }
    setLoading(true);
    setError(null);
    setGeneratedImage(null);
    try {
      const imageUrl = await generateImage(prompt, selectedAspectRatio);
      setGeneratedImage(imageUrl);
    } catch (err) {
      setError(err instanceof Error ? err.message : "An unknown error occurred.");
    } finally {
      setLoading(false);
    }
  }, [prompt, selectedAspectRatio]);

  return (
    <div className="flex flex-col gap-6">
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="e.g., A majestic lion wearing a crown, cinematic, 4k"
          className="w-full h-24 p-3 bg-gray-700 border-2 border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors"
          disabled={loading}
        />
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
          <div className="flex items-center gap-2 text-gray-300">
            <Icon icon="aspectRatio" className="w-5 h-5" />
            <span className="font-medium">Aspect Ratio:</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {aspectRatios.map((ratio) => (
              <button
                key={ratio}
                type="button"
                onClick={() => setSelectedAspectRatio(ratio)}
                className={`px-3 py-1.5 text-sm font-semibold rounded-md transition-all duration-200 ${
                  selectedAspectRatio === ratio
                    ? 'bg-indigo-600 text-white ring-2 ring-offset-2 ring-offset-gray-800 ring-indigo-500'
                    : 'bg-gray-600 text-gray-300 hover:bg-gray-500'
                }`}
                disabled={loading}
              >
                {ratio}
              </button>
            ))}
          </div>
        </div>
        <button
          type="submit"
          disabled={loading || !prompt.trim()}
          className="w-full sm:w-auto self-start bg-indigo-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-indigo-700 disabled:bg-gray-500 disabled:cursor-not-allowed transition-all duration-200 flex items-center justify-center gap-2"
        >
          {loading ? <><Spinner size="w-5 h-5" /> Generating...</> : 'Generate Image'}
        </button>
      </form>
      {error && <p className="text-red-400 bg-red-900/50 p-3 rounded-lg">{error}</p>}
      <div className="w-full bg-gray-900/50 min-h-[300px] rounded-lg flex items-center justify-center p-4 border-2 border-dashed border-gray-600">
        {loading ? (
          <div className="text-center text-gray-400">
            <Spinner />
            <p className="mt-2">Generating your masterpiece...</p>
          </div>
        ) : generatedImage ? (
          <img src={generatedImage} alt="Generated" className="max-w-full max-h-[60vh] rounded-md shadow-lg" />
        ) : (
          <p className="text-gray-500">Your generated image will appear here.</p>
        )}
      </div>
    </div>
  );
};

export default GenerateImage;
