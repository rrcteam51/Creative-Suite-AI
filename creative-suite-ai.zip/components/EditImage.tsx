
import React, { useState, useCallback, useRef } from 'react';
import { editImage } from '../services/geminiService';
import { ImageData } from '../types';
import Spinner from './Spinner';

const EditImage: React.FC = () => {
  const [prompt, setPrompt] = useState<string>('');
  const [sourceImage, setSourceImage] = useState<ImageData | null>(null);
  const [editedImage, setEditedImage] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSourceImage({
          base64: reader.result as string,
          mimeType: file.type,
        });
        setEditedImage(null);
        setError(null);
      };
      reader.onerror = () => {
        setError("Failed to read the image file.");
      }
      reader.readAsDataURL(file);
    }
  };
  
  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || !sourceImage) {
      setError("Please upload an image and provide an editing prompt.");
      return;
    }
    setLoading(true);
    setError(null);
    setEditedImage(null);
    try {
      const imageUrl = await editImage(prompt, sourceImage);
      setEditedImage(imageUrl);
    } catch (err) {
      setError(err instanceof Error ? err.message : "An unknown error occurred.");
    } finally {
      setLoading(false);
    }
  }, [prompt, sourceImage]);

  return (
    <div className="flex flex-col gap-6">
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          accept="image/*"
          className="hidden"
          disabled={loading}
        />
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          disabled={loading}
          className="w-full border-2 border-dashed border-gray-600 hover:border-indigo-500 bg-gray-700/50 rounded-lg p-4 text-gray-400 hover:text-white transition-colors text-center"
        >
          {sourceImage ? 'Change Image' : 'Click to Upload Image'}
        </button>

        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="e.g., Add a retro filter, make it black and white"
          className="w-full h-24 p-3 bg-gray-700 border-2 border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors"
          disabled={loading || !sourceImage}
        />
        <button
          type="submit"
          disabled={loading || !prompt.trim() || !sourceImage}
          className="w-full sm:w-auto self-start bg-indigo-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-indigo-700 disabled:bg-gray-500 disabled:cursor-not-allowed transition-all duration-200 flex items-center justify-center gap-2"
        >
          {loading ? <><Spinner size="w-5 h-5" /> Editing...</> : 'Edit Image'}
        </button>
      </form>

      {error && <p className="text-red-400 bg-red-900/50 p-3 rounded-lg">{error}</p>}
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="w-full bg-gray-900/50 min-h-[300px] rounded-lg flex flex-col items-center justify-center p-4 border-2 border-dashed border-gray-600">
          <h3 className="text-lg font-semibold text-gray-400 mb-2">Original</h3>
          {sourceImage ? (
            <img src={sourceImage.base64} alt="Source" className="max-w-full max-h-[40vh] rounded-md shadow-lg" />
          ) : (
            <p className="text-gray-500">Upload an image to start.</p>
          )}
        </div>
        <div className="w-full bg-gray-900/50 min-h-[300px] rounded-lg flex flex-col items-center justify-center p-4 border-2 border-dashed border-gray-600">
          <h3 className="text-lg font-semibold text-gray-400 mb-2">Edited</h3>
          {loading ? (
            <div className="text-center text-gray-400">
              <Spinner />
              <p className="mt-2">Applying edits...</p>
            </div>
          ) : editedImage ? (
            <img src={editedImage} alt="Edited" className="max-w-full max-h-[40vh] rounded-md shadow-lg" />
          ) : (
            <p className="text-gray-500">Your edited image will appear here.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default EditImage;
